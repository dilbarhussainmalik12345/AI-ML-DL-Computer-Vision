function [ entropia, inercia, energia  ] = extraerCTexturas( IRecorteRGB, IMascaraC)
% ########################################################################
% Project AUTOMATIC CLASSIFICATION OF ORANGES BY SIZE AND DEFECTS USING 
% COMPUTER VISION TECHNIQUES 2018
% juancarlosmiranda81@gmail.com
% ########################################################################
% Obtiene características de textura a partir de una imagen de color

entropia=0.0; 
inercia=0.0; 
energia=0.0;
end %fin de la funcion



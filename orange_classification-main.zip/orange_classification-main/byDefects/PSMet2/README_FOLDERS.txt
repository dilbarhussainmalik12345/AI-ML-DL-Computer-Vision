
%% dataset hierarchy
%|__/DATASET/
%       |__/inputToLearn/ -> RGB images
%       |__/inputMarked/ -> RGB images with masks
%
%|__/PREPROCESSED_DATASET/
%       |__/inputTest -> folder with images for tests
%       |__/inputTraining -> folder with images for training.



% Temporal data folder hierarchy
% 
%|__/HOME/DATASET/
%   |__/sFrutas
%   |__/ROIDefC
%   |__/ROIDefBin
%   |__/ROICalyxC
%   |__/ROICalyxBin
%   |__/MROI
%   |__/MRM
%   |__/MDefColor
%   |__/MDefBin
%   |__/MCalyxColor
%   |__/MCalyxBin
%   |__/ISFrutas
%   |__/IROI
%   |__/IRM
%   |__/IBR
%   |__/cDefectos
%   |__/cCalyx
%